package com.example.proyectobuscaminas_v1;

import androidx.annotation.NonNull;
import androidx.gridlayout.widget.GridLayout;
import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;

import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;

import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

@SuppressLint("ResourceType")
public class MainActivity extends AppCompatActivity {

    //region DECLARACIÓN DE VARIABLES
    Button casilla, reiniciar;
    TextView txtPuntuacion, txtCreditos, txtBanderas;
    int puntos, banderas, numCasillas, totalCasillas;
    boolean nivel;
    GridLayout grid;
    ArrayList<Button> listaCasillas = new ArrayList();
    ArrayList<Integer> listaPulsadas = new ArrayList();
    ArrayList<Integer> listaMinas = new ArrayList();
    ArrayList<Integer> listaBanderas = new ArrayList();
    MediaPlayer mpInicio, mpMusica, mpExplosion, mpCasilla, mpBandera;
    //endregion  DECLARACION DE VARIABLES
    //---------------------------------------------------------------------

    //region MÉTODO ON CREATE
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        reiniciar = (Button) findViewById(R.id.btnReiniciar);
        txtPuntuacion = (TextView) findViewById(R.id.txtPuntuacion);
        txtPuntuacion.setText("Puntuacion actual: " + puntos);
        txtCreditos = (TextView) findViewById(R.id.txtCreditos);
        txtBanderas = (TextView) findViewById(R.id.txtBanderas);
        txtBanderas.setText("Banderas: " + banderas);

        mpInicio = MediaPlayer.create(this, R.raw.inicio);
        mpMusica = MediaPlayer.create(this, R.raw.buscaminas);
        mpExplosion = MediaPlayer.create(this, R.raw.explosion);
        mpCasilla = MediaPlayer.create(this, R.raw.casilla);
        mpBandera = MediaPlayer.create(this, R.raw.bandera);

        nuevoFacil();

        mpInicio.start();

        mpInicio.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
            @Override
            public void onCompletion(MediaPlayer mediaPlayer) {
                mpInicio.stop();
                mpMusica.start();
                mpMusica.setLooping(true);
            }
        });

        reiniciar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (nivel == true) {
                    reseteaNivel();
                    nuevoFacil();
                } else {
                    reseteaNivel();
                    nuevoDificl();
                }
            }
        });
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO RESETEA NIVEL -> LIMPIA TODOS LOS DATOS
    private void reseteaNivel() {
        listaCasillas.clear();
        listaMinas.clear();
        listaPulsadas.clear();
        listaBanderas.clear();
        grid.removeAllViews();
        puntos = 0;
        txtPuntuacion.setText("Puntuación actual: " + puntos);
        banderas = 0;
        txtBanderas.setText("Banderas: " + banderas);
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODOS NUEVO -> DAN FORMA AL GRID
    private void nuevoFacil() {
        numCasillas = 8;
        totalCasillas = 64;
        nivel = true;
        grid = (GridLayout) findViewById(R.id.gridBotones);
        int id;

        for (int i = 0; i < 64; i++) {
            casilla = new Button(this);
            casilla.setLayoutParams(new ViewGroup.LayoutParams(120, 120));
            id = i;
            casilla.setBackgroundResource(R.drawable.casilla);
            casilla.setId(id);
            grid.setColumnCount(8);
            grid.setRowCount(8);
            grid.addView(casilla);
            pulsaCasilla64(casilla);
            listaCasillas.add(casilla);
        }
        generaMinas64();
    }

    private void nuevoDificl() {
        numCasillas = 10;
        totalCasillas = 100;
        nivel = false;
        grid = (GridLayout) findViewById(R.id.gridBotones);
        int id;

        for (int i = 0; i < 100; i++) {
            casilla = new Button(this);
            casilla.setLayoutParams(new ViewGroup.LayoutParams(100, 100));
            id = i;
            casilla.setBackgroundResource(R.drawable.casilla);
            casilla.setId(id);
            grid.setColumnCount(10);
            grid.setRowCount(10);
            grid.addView(casilla);
            pulsaCasilla100(casilla);
            listaCasillas.add(casilla);
        }
        generaMinas100();
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO PULSACASILLA -> MÉTODO QUE GESTIONA LA FUNCIÓN DE PULSAR LAS CASILLAS
    private void pulsaCasilla64(Button casilla) {
        casilla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Casilla pulsada: " + casilla.getId());
                if (listaBanderas.contains(casilla.getId())) {
                    for (int i = 0; i < listaBanderas.size(); i++) {
                        if (listaBanderas.get(i).equals(casilla.getId())) {
                            listaBanderas.remove(i);
                            banderas--;
                            txtBanderas.setText("Banderas: " + banderas);
                        }
                    }
                }

                //Si la casilla está en al lista de las minas explota y poner mensaje final de puntos
                if (listaMinas.contains(casilla.getId())) {
                    explota64();
                    txtPuntuacion.setText("Puntuación final: " + puntos);
                } else {
                    //Si no llama al metodo que marca la casilla como cesped
                    marcarCasillaComoCesped(casilla);
                }
                //Se deshabilita la casilla
                casilla.setEnabled(false);
            }
        });

        casilla.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                //Mientras las banderas sean menores que 8 establece la casilla con el diseño de la bandera
                //y comprueba que no esté en la lista de banderas. Si está dentro, recorre la lista y borrará esa bandera
                if (banderas < 8) {
                    casilla.setBackgroundResource(R.drawable.casillabandera);
                    if (!listaBanderas.contains(casilla.getId())) {
                        mpBandera.start();
                        listaBanderas.add(casilla.getId());
                        banderas++;
                        txtBanderas.setText("Banderas: " + banderas);
                    } else {
                        casilla.setBackgroundResource(R.drawable.casilla);
                        for (int i = 0; i < listaBanderas.size(); i++) {
                            listaBanderas.remove(casilla.getId());
                            banderas--;
                            txtBanderas.setText("Banderas: " + banderas);
                        }
                    }
                }
                return true;
            }
        });
    }


    private void pulsaCasilla100(Button casilla) {

        casilla.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                System.out.println("Casilla pulsada: " + casilla.getId());
                if (listaBanderas.contains(casilla.getId())) {
                    for (int i = 0; i < listaBanderas.size(); i++) {
                        if (listaBanderas.get(i).equals(casilla.getId())) {
                            listaBanderas.remove(i);
                            banderas--;
                            txtBanderas.setText("Banderas: " + banderas);
                        }
                    }
                }

                if (listaMinas.contains(casilla.getId())) {
                    explota100();
                    txtPuntuacion.setText("Puntuación final: " + puntos);
                } else {
                    marcarCasillaComoCesped100(casilla);
                }
                casilla.setEnabled(false);
            }
        });

        casilla.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (banderas < 10) {
                    casilla.setBackgroundResource(R.drawable.casillabandera);
                    if (!listaBanderas.contains(casilla.getId())) {
                        mpBandera.start();
                        listaBanderas.add(casilla.getId());
                        banderas++;
                        txtBanderas.setText("Banderas: " + banderas);
                    } else {
                        casilla.setBackgroundResource(R.drawable.casilla);
                        for (int i = 0; i < listaBanderas.size(); i++) {
                            listaBanderas.remove(i);
                            banderas--;
                            txtBanderas.setText("Banderas: " + banderas);
                        }
                    }
                }
                return true;
            }
        });
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO CHECK IF -> COMPRUEBA QUE NO SE PASE DEL MARGEN DEL TABLERO
    private boolean checkIfLeftNeighbour(int casillaEntero) {
        boolean esIzda;
        if (casillaEntero % numCasillas == 0) {
            esIzda = true;
        } else {
            esIzda = false;
        }
        return esIzda;
    }

    private boolean checkIfRightNeighbour(int casillaEntero) {
        boolean esDcha;
        if (((casillaEntero + 1) % numCasillas) == 0) {
            esDcha = true;
        } else {
            esDcha = false;
        }
        return esDcha;
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO BARRECASILLAS -> LEVANTA LAS CASILLAS DE AL REDEDOR
    private void accionBarrerCasillasCesped(Button casilla) {
        int idCasilla = casilla.getId();
        System.out.println("Voy a barrer la casilla " + idCasilla);

        //Las comprobaciones son la misma para todas las casillas, salvo las que esten
        //a la izda y derecha, donde se llamará al metodo que comprueba que no se
        //pasa del margen
        //Declara variable entera que su valor sera el id de la casilla pulsada y la operacion
        //pertinente para hacer referencia a las casillas del alrededor
        //Comprueba que no esté en la lista de minas, tampoco en la de las pulsadas y llamarña
        //al metodo que setea la casilla como cesped

        //region Casillas de arriba
        int idCasillaArribaIzda = idCasilla - (numCasillas + 1);
        if (idCasillaArribaIzda >= 0 && !listaMinas.contains(idCasillaArribaIzda) &&
                !listaPulsadas.contains(idCasillaArribaIzda) && !checkIfLeftNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaArribaIzda));
        }

        int idCasillaArribaMedio = idCasilla - numCasillas;
        if (idCasillaArribaMedio >= 0 && !listaMinas.contains(idCasillaArribaMedio) &&
                !listaPulsadas.contains(idCasillaArribaMedio)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaArribaMedio));
        }

        int idCasillaArribaDcha = idCasilla - (numCasillas - 1);
        if (idCasillaArribaDcha >= 0 && !listaMinas.contains(idCasillaArribaDcha) &&
                !listaPulsadas.contains(idCasillaArribaDcha) && !checkIfRightNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaArribaDcha));
        }
        //endregion

        //region Casillas laterales del medio
        int idCasillaIzdaMedio = idCasilla - 1;
        if (idCasillaIzdaMedio >= 0 && !listaMinas.contains(idCasillaIzdaMedio) &&
                !listaPulsadas.contains(idCasillaIzdaMedio) && !checkIfLeftNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaIzdaMedio));
        }

        int idCasillaDchaMedio = idCasilla + 1;
        if (idCasillaDchaMedio <= totalCasillas && !listaMinas.contains(idCasillaDchaMedio) &&
                !listaPulsadas.contains(idCasillaDchaMedio) && !checkIfRightNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaDchaMedio));
        }
        //endregion

        //region Casillas de abajo
        int idCasillaAbajoIzda = idCasilla + (numCasillas - 1);
        if (idCasillaAbajoIzda < totalCasillas && !listaMinas.contains(idCasillaAbajoIzda) &&
                !listaPulsadas.contains(idCasillaAbajoIzda) && !checkIfLeftNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaAbajoIzda));
        }
        int idCasillaAbajoMedio = idCasilla + numCasillas;
        if (idCasillaAbajoMedio < totalCasillas && !listaMinas.contains(idCasillaAbajoMedio) &&
                !listaPulsadas.contains(idCasillaAbajoMedio)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaAbajoMedio));
        }
        int idCasillaAbajoDcha = idCasilla + (numCasillas + 1);
        if (idCasillaAbajoDcha < totalCasillas && !listaMinas.contains(idCasillaAbajoDcha) &&
                !listaPulsadas.contains(idCasillaAbajoDcha) && !checkIfRightNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped(listaCasillas.get(idCasillaAbajoDcha));
        }
    }

    private void accionBarrerCasillasCesped100(Button casilla) {
        int idCasilla = casilla.getId();
        System.out.println("Voy a barrer la casilla " + idCasilla);

        //region Casillas de arriba
        int idCasillaArribaIzda = idCasilla - (numCasillas + 1);
        if (idCasillaArribaIzda >= 0 && !listaMinas.contains(idCasillaArribaIzda) &&
                !listaPulsadas.contains(idCasillaArribaIzda) && !checkIfLeftNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaArribaIzda));
        }

        int idCasillaArribaMedio = idCasilla - numCasillas;
        if (idCasillaArribaMedio >= 0 && !listaMinas.contains(idCasillaArribaMedio) &&
                !listaPulsadas.contains(idCasillaArribaMedio)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaArribaMedio));
        }

        int idCasillaArribaDcha = idCasilla - (numCasillas - 1);
        if (idCasillaArribaDcha >= 0 && !listaMinas.contains(idCasillaArribaDcha) &&
                !listaPulsadas.contains(idCasillaArribaDcha) && !checkIfRightNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaArribaDcha));
        }
        //endregion

        //region Casillas laterales del medio
        int idCasillaIzdaMedio = idCasilla - 1;
        if (idCasillaIzdaMedio >= 0 && !listaMinas.contains(idCasillaIzdaMedio) &&
                !listaPulsadas.contains(idCasillaIzdaMedio) && !checkIfLeftNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaIzdaMedio));
        }

        int idCasillaDchaMedio = idCasilla + 1;
        if (idCasillaDchaMedio <= totalCasillas && !listaMinas.contains(idCasillaDchaMedio) &&
                !listaPulsadas.contains(idCasillaDchaMedio) && !checkIfRightNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaDchaMedio));
        }
        //endregion

        //region Casillas de abajo
        int idCasillaAbajoIzda = idCasilla + (numCasillas - 1);
        if (idCasillaAbajoIzda < totalCasillas && !listaMinas.contains(idCasillaAbajoIzda) &&
                !listaPulsadas.contains(idCasillaAbajoIzda) && !checkIfLeftNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaAbajoIzda));
        }
        int idCasillaAbajoMedio = idCasilla + numCasillas;
        if (idCasillaAbajoMedio < totalCasillas && !listaMinas.contains(idCasillaAbajoMedio) &&
                !listaPulsadas.contains(idCasillaAbajoMedio)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaAbajoMedio));
        }
        int idCasillaAbajoDcha = idCasilla + (numCasillas + 1);
        if (idCasillaAbajoDcha < totalCasillas && !listaMinas.contains(idCasillaAbajoDcha) &&
                !listaPulsadas.contains(idCasillaAbajoDcha) && !checkIfRightNeighbour(idCasilla)) {
            //Es cesped
            marcarCasillaComoCesped100(listaCasillas.get(idCasillaAbajoDcha));
        }
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO MARCACASILLACOMOCESPED -> ESTABLECE LA CASILLA SIN MINA NI NUMERO
    private void marcarCasillaComoCesped(Button casilla) {
        //Establece el diseño de la casilla como si fuera cesped, así como
        //el resto de sus características. Comprueba que no haya bombas cerca: si las hay llama al metodo
        //barrer para comprobar cuantas hay
        //Comprueba tambien si gana y de ser así deshabilita todas las casillas

        listaPulsadas.add(casilla.getId());
        casilla.setBackgroundResource(R.drawable.casillavacia);
        casilla.setEnabled(false);
        int bombasAdyacentes = getNumerosBombasAdyacentes(casilla);
        mpCasilla.start();
        puntos += 10;
        txtPuntuacion.setText("Puntuación actual: " + puntos);

        if (bombasAdyacentes == 0) {
            accionBarrerCasillasCesped(casilla);
        } else {
            setEstiloCasillaNumeros(casilla, bombasAdyacentes);
            casilla.setEnabled(false);
        }
        if (listaPulsadas.size() == (totalCasillas - numCasillas)) {
            txtPuntuacion.setText("Has ganado con " + puntos + " puntos :D ");
            for (Button c : listaCasillas) {
                c.setEnabled(false);
            }
        }
    }

    private void marcarCasillaComoCesped100(Button casilla) {
        listaPulsadas.add(casilla.getId());
        casilla.setBackgroundResource(R.drawable.casillavacia);
        casilla.setEnabled(false);
        int bombasAdyacentes = getNumerosBombasAdyacentes100(casilla);
        mpCasilla.start();
        puntos += 10;
        txtPuntuacion.setText("Puntuación actual: " + puntos);
        if (bombasAdyacentes == 0) {
            accionBarrerCasillasCesped100(casilla);
        } else {
            setEstiloCasillaNumeros100(casilla, bombasAdyacentes);
            casilla.setEnabled(false);
        }
        if (listaPulsadas.size() == (totalCasillas - numCasillas)) {
            txtPuntuacion.setText("Has ganado con " + puntos + " puntos :D ");
            for (Button c : listaCasillas) {
                c.setEnabled(false);
            }
        }
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO GETNUMEROSBOMBASADYACENTES -> DETECTA QUE MINAS HAY CERCA DE LA CASILLA PULSADA
    @SuppressLint("ResourceType")
    private int getNumerosBombasAdyacentes(Button casilla) {
        int minasCerca = 0;

        //CASILLAS DE LA DERECHA
        //Si el id de la casilla que hemos pulsado y pasado al método, es múltiplo de 8 (pues son las casillas de al rededor)
        if (!checkIfRightNeighbour(casilla.getId())) {
            //CASILLA DCHA-ARRIBA
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 7
            if (listaMinas.contains(((casilla.getId()) - 7))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }

            //CASILLA(DCHA-MEDIO)
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla más 1
            if (listaMinas.contains((casilla.getId()) + 1)) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }

            //CASILLA DCHA-ABAJO
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla más 9
            if (listaMinas.contains(((casilla.getId()) + 9))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }
        }

        //CASILLAS DE LA IZQUIERDA
        if (!checkIfLeftNeighbour(casilla.getId())) {
            //CASILLA IZDA-ARRIBA
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 9
            if (listaMinas.contains(((casilla.getId()) - 9))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }

            //CASILLA(IZDA-MEDIO)
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 1
            if (listaMinas.contains((casilla.getId()) - 1)) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }
            //CASILLA IZDA-ABAJO
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla más 7
            if (listaMinas.contains(((casilla.getId()) + 7))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }
        }

        //CASILLA MEDIO-ARRIBA
        //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 8
        if (listaMinas.contains(((casilla.getId()) - 8))) {
            //Entonces suma a la variable minasCerca la cifra de 1
            minasCerca++;
        }

        //CASILLA MEDIO-ABAJO
        //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla mas 8
        if (listaMinas.contains(((casilla.getId()) + 8))) {
            //Entonces suma a la variable minasCerca la cifra de 1
            minasCerca++;
        }
        return minasCerca;
    }

    @SuppressLint("ResourceType")
    private int getNumerosBombasAdyacentes100(Button casilla) {
        int minasCerca = 0;

        //CASILLAS DE LA DERECHA
        //Si el id de la casilla que hemos pulsado y pasado al método, es múltiplo de 8 (pues son las casillas de al rededor)
        if (!checkIfRightNeighbour(casilla.getId())) {
            //CASILLA DCHA-ARRIBA
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 7
            if (listaMinas.contains(((casilla.getId()) - 9))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }

            //CASILLA(DCHA-MEDIO)
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla más 1
            if (listaMinas.contains((casilla.getId()) + 1)) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }

            //CASILLA DCHA-ABAJO
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla más 9
            if (listaMinas.contains(((casilla.getId()) + 11))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }
        }

        //CASILLAS DE LA IZQUIERDA
        if (!checkIfLeftNeighbour(casilla.getId())) {
            //CASILLA IZDA-ARRIBA
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 9
            if (listaMinas.contains(((casilla.getId()) - 11))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }

            //CASILLA(IZDA-MEDIO)
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 1
            if (listaMinas.contains((casilla.getId()) - 1)) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }
            //CASILLA IZDA-ABAJO
            //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla más 7
            if (listaMinas.contains(((casilla.getId()) + 9))) {
                //Entonces suma a la variable minasCerca la cifra de 1
                minasCerca++;
            }
        }

        //CASILLA MEDIO-ARRIBA
        //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla menos 8
        if (listaMinas.contains(((casilla.getId()) - 10))) {
            //Entonces suma a la variable minasCerca la cifra de 1
            minasCerca++;
        }

        //CASILLA MEDIO-ABAJO
        //Comprueba si la lista de las minas contiene el resultado  del ID de la casilla mas 8
        if (listaMinas.contains(((casilla.getId()) + 10))) {
            //Entonces suma a la variable minasCerca la cifra de 1
            minasCerca++;
        }
        return minasCerca;
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO SETESTILOCASILLANUMEROS -> PONE EL NUMERO DE MINAS CERCA
    private void setEstiloCasillaNumeros(Button casilla, int minasCerca) {
        //Hace un switch para que, si la cantidad en minasCerca coincide con una de las siguientes...
        switch (minasCerca) {
            case 0:
                //Si es cero minas, se queda con el cesped sin numero
                casilla.setBackgroundResource(R.drawable.casillavacia);
                break;
            case 1:
                //Si es una mina, se queda con el cesped con el numero 1
                casilla.setBackgroundResource(R.drawable.casilla1);
                break;
            case 2:
                //Si son dos minas, se queda con el cesped con el numero 2
                casilla.setBackgroundResource(R.drawable.casilla2);
                break;
            case 3:
                //Si son tres minas, se queda con el cesped con el numero 3
                casilla.setBackgroundResource(R.drawable.casilla3);
                break;
            case 4:
                //Si son cuatro minas, se queda con el cesped con el numero 4
                casilla.setBackgroundResource(R.drawable.casilla4);
                break;
            case 5:
                //Si son cinco minas, se queda con el cesped con el numero 5
                casilla.setBackgroundResource(R.drawable.casilla5);
                break;
            case 6:
                //Si son seis minas, se queda con el cesped con el numero 6
                casilla.setBackgroundResource(R.drawable.casilla6);
                break;
            case 7:
                //Si son siete minas, se queda con el cesped con el numero 7
                casilla.setBackgroundResource(R.drawable.casilla7);
                break;
            case 8:
                //Si son ocho minas, se queda con el cesped con el numero 8
                casilla.setBackgroundResource(R.drawable.casilla8);
                break;
        }
    }

    private void setEstiloCasillaNumeros100(Button casilla, int minasCerca) {
        //Hace un switch para que, si la cantidad en minasCerca coincide con una de las siguientes...
        switch (minasCerca) {
            case 0:
                //Si es cero minas, se queda con el cesped sin numero
                casilla.setBackgroundResource(R.drawable.casillavacia);
                break;
            case 1:
                //Si es una mina, se queda con el cesped con el numero 1
                casilla.setBackgroundResource(R.drawable.casilla1);
                break;
            case 2:
                //Si son dos minas, se queda con el cesped con el numero 2
                casilla.setBackgroundResource(R.drawable.casilla2);
                break;
            case 3:
                //Si son tres minas, se queda con el cesped con el numero 3
                casilla.setBackgroundResource(R.drawable.casilla3);
                break;
            case 4:
                //Si son cuatro minas, se queda con el cesped con el numero 4
                casilla.setBackgroundResource(R.drawable.casilla4);
                break;
            case 5:
                //Si son cinco minas, se queda con el cesped con el numero 5
                casilla.setBackgroundResource(R.drawable.casilla5);
                break;
            case 6:
                //Si son seis minas, se queda con el cesped con el numero 6
                casilla.setBackgroundResource(R.drawable.casilla6);
                break;
            case 7:
                //Si son siete minas, se queda con el cesped con el numero 7
                casilla.setBackgroundResource(R.drawable.casilla7);
                break;
            case 8:
                //Si son ocho minas, se queda con el cesped con el numero 8
                casilla.setBackgroundResource(R.drawable.casilla8);
                break;
        }
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO GENERAMINAS -> GENERA ALEATORIAMENTE LAS MINAS
    private void generaMinas64() {
        int posMina;
        //Obtiene una casilla al azar para que sea una bomba
        for (int i = 0; i < numCasillas; i++) {
            posMina = (int) (64 * Math.random());
            if (listaMinas.contains(posMina)) {
                i--;
            } else {
                listaMinas.add(posMina);
            }
        }
        System.out.println(listaMinas);
    }

    private void generaMinas100() {
        int posMina;

        for (int i = 0; i < numCasillas; i++) {
            posMina = (int) (100 * Math.random());
            if (listaMinas.contains(posMina)) {
                i--;
            } else {
                listaMinas.add(posMina);
            }
        }
        System.out.println(listaMinas);
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODO EXPLOTA -> DETERMINA SI LA CASILLA PULSADA ES UNA MINA O NO
    private void explota64() {
        //Recorre todas las casillas para comprobar cuales tienen bomba y deshabilitar todas
        for (int i = 0; i < 64; i++) {
            for (int j = 0; j < listaMinas.size(); j++) {
                if (listaCasillas.get(i).getId() == listaMinas.get(j)) {
                    listaCasillas.get(i).setBackgroundResource(R.drawable.casillamina);
                    mpExplosion.start();
                    break;
                }
            }
            listaCasillas.get(i).setEnabled(false);
        }
    }

    private void explota100() {
        for (int i = 0; i < 100; i++) {
            for (int j = 0; j < listaMinas.size(); j++) {
                if (listaCasillas.get(i).getId() == listaMinas.get(j)) {
                    listaCasillas.get(i).setBackgroundResource(R.drawable.casillamina);
                    mpExplosion.start();
                    break;
                }
            }
            listaCasillas.get(i).setEnabled(false);
        }
    }
    //endregion
    //---------------------------------------------------------------------

    //region MÉTODOS DIFICULTAD -> SETEA LA DIFICULTAD LLAMANDO A LOS MÉTODOS NECESARIOS
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater m = getMenuInflater();
        m.inflate(R.menu.menu_opciones, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        int iden = item.getItemId();
        switch (iden) {
            case R.id.facil:
                Toast.makeText(getApplicationContext(), "Nivel: Fácil", Toast.LENGTH_LONG).show();
                reseteaNivel();
                nuevoFacil();
                numCasillas = 8;
                break;
            case R.id.dificil:
                Toast.makeText(getApplicationContext(), "Nivel: Difícil", Toast.LENGTH_LONG).show();
                reseteaNivel();
                nuevoDificl();
                numCasillas = 10;
                break;
        }
        return super.onOptionsItemSelected(item);
    }

    //endregion - - C
    //---------------------------------------------------------------------
}