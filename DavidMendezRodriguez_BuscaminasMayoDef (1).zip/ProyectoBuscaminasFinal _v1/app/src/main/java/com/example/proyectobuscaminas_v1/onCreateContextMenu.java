package com.example.proyectobuscaminas_v1;

import android.view.Menu;
import android.view.View;

public interface onCreateContextMenu extends View.OnCreateContextMenuListener {
    boolean onCreateContextMenu(Menu menu);
}
